sudo apt-get update 

sudo apt-get upgrade -y
apt install python3-pip -y,
pip3 install rsa
pip3 install thrift
pip3 install requests
pip3 install bs4
pip3 install gtts
pip3 install googletrans
pip3 install goslate
pip3 install wikipedia
pip3 install BeautifulSoup
pip3 install tweepy
pip3 install pyowm
pip3 install pygame
pip3 install humanfriendly
pip3 install html5lib
pip3 install shutil
pip3 install akad
pip3 install humanize
pip3 install pytz
pip3 install pafy
pip3 install youtube_dl
pip3 install wikiapi
pip3 install selenium
pip3 install schematics
pip3 install null
pip3 install Naked
pip3 install --upgrade